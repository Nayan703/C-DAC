package Q1;
//package Q1;
//
//import java.util.Scanner;
//class Loan {
//	private double principal;
//	private double i;
//	private int y;
//
//	public void acceptRecord() {
//
//		try (Scanner sc = new Scanner(System.in)) {
//			System.out.print("enter the Loan amount : ");
//			 principal = sc.nextDouble();
//			System.out.print("Enter the anual interest rate : ");
//			 i = sc.nextDouble();
//			System.out.print("Enter the term of loan in years :");
//			 y = sc.nextInt();
//		}
//
//	}
//
//	public double calculateMonthlyPayment() {
//		double monthlyInterestRate = i / 12 / 100;
//		double numberOfMonths = y * 12;
//		double monthlyPayment = (principal * (monthlyInterestRate * (Math.pow(1 + monthlyInterestRate, numberOfMonths)))
//				/ (Math.pow(1 + monthlyInterestRate, numberOfMonths) - 1));
//		return monthlyPayment;
//
//	}
//
//	public void printRecord() {
//		double monthlyPayment = calculateMonthlyPayment();
//		double totalPayment = (monthlyPayment * y * 12);
//
//		System.out.println("monthlyPayment: " + monthlyPayment);
//		System.out.println("TotalPayment: " + totalPayment);
//	}
//
//}
//
//public class LoanAmortizationCalculator {
//	public static void main(String[] args) {
//		Loan ref = new Loan();
//		ref.acceptRecord();
//		ref.printRecord();
//	}
//}
//OUTPUT=enter the Loan amount : 8000
//Enter the anual interest rate : 4
//Enter the term of loan in years :2
//monthlyPayment: 347.3993773661851
//TotalPayment: 8337.585056788443
