package Q4;

import java.util.Scanner;
class Compound {

		
		double  annualInterestRate ;
		double  numberOfCompounds;
		int years;
		double principal;
		double futureValue, totalInterest;
		public void acceptRecord() {
			Scanner sc = new Scanner (System.in);	
			
			System.out.print("enter Annual interest Rate : ");
			annualInterestRate= sc.nextDouble();
			System.out.print("Enter number of compounds  : ");
			numberOfCompounds=sc.nextDouble();
			System.out.print("Enter the years            : ");
			years= sc.nextInt();
			System.out.print("enter the compound         : ");
			principal = sc.nextDouble();
			
		}
		public void calculateFutureValue() {
			futureValue = (principal * (1 + annualInterestRate / Math.pow(annualInterestRate, numberOfCompounds)) * years);
	         totalInterest = futureValue - principal;
		}
		
		public void printRecord() {
			System.out.println("Future Value         : "+futureValue);
			System.out.println("Total interest erned : ₹" +totalInterest);
		}
		
		
	}



	public class CompoundInterestCalculator {
		public static void main(String[] args) {
			Compound CI= new Compound();
			CI.acceptRecord();
			CI.calculateFutureValue();
			CI.printRecord();
			
		}

	}

//	OUTPUT=enter Annual interest Rate : 7
//			Enter number of compounds  : 5
//			Enter the years            : 2
//			enter the compound         : 5
//			Future Value         : 10.004164931278634
//			Total interest erned : ₹5.004164931278634
