package Q2;
//2. Compound Interest Calculator for Investment
//Develop a system to compute the future value of an investment with compound interest. The system should:
//1.	Accept the initial investment amount, annual interest rate, number of times the interest is compounded per year, and investment duration (in years) from the user.
//2.	Calculate the future value of the investment using the formula:
//o	Future Value Calculation:
//	futureValue = principal * (1 + annualInterestRate / numberOfCompounds)^(numberOfCompounds * years)
//o	Total Interest Earned: totalInterest = futureValue - principal
//3.	Display the future value and the total interest earned, in Indian Rupees (₹).
//Define class CompoundInterestCalculator with methods acceptRecord , calculateFutureValue, printRecord and test the functionality in main method.


import java.util.Scanner;

	class Discount{
		float discountAmount;
		float originalPrice;
		float discountRate;
		float finalPrice;
		
		public void acceptRecord() {
			Scanner sc = new Scanner (System.in);
			System.out.print("Enter original price:   ");
			originalPrice=sc.nextFloat();
			System.out.print("Enter Discountrate:     ");
			discountRate= sc.nextFloat();
			
			
		}
		public void calculateDiscount() {
			discountAmount = originalPrice * (discountRate / 100);
			finalPrice = originalPrice - discountAmount;
			
		}
		public void printRecord() {
			System.out.println("Original amount is : "+originalPrice);
			System.out.println("Discount rate is   : "+discountRate);
			System.out.println("Discount Amount is : "+discountAmount);
			System.out.println("Final price is     : "+finalPrice);	
		}

	}

	public class Discountcalculator {
		public static void main(String[] args) {
			Discount dc = new Discount();
			dc.acceptRecord();
			dc.calculateDiscount();
			dc.printRecord();

}
	}

//	OUTPUT=Enter original price:   87
//			Enter Discountrate:     20
//			Original amount is : 87.0
//			Discount rate is   : 20.0
//			Discount Amount is : 17.4
//			Final price is     : 69.6
//
