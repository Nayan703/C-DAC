package Q1_java.lang.Boolean;
// b. Declare a method-local variable status of type boolean with the value true and convert it to a String 
   //    using the toString method. (Hint: Use Boolean.toString(Boolean) ).
/*public class Example2 {

	public static void main(String[] args) {
		Boolean status = true;
		String statusString = Boolean.toString(status);
				System.out.println("String str is : " + statusString);
		
		

	}

}
//OUTPUTString str is : true
*/

/* Declare a method-local variable strStatus of type String  with the value "true" and convert it to a boo
lean using the parseBoolean method. (Hint: Use Boolean.parseBoolean(String)).
public class Example2 {
	public static void main(String[] args) { 
		String strStatus = "true";
		 boolean status  = Boolean.parseBoolean(strStatus);
		 System.out.println("Boolean strStrinfg is " + status);
	}
}
OUTPUT:-Boolean strStrinfg is true


/* d. Declare a method-local variable strStatus of type String with the value "1" or "0" and attempt to convert 
it to a boolean. (Hint: parseBoolean method will not work as expected with "1" or "0").

public class Example2 {
	public static void main(String[] args) { 
		String strStatus = "0";
		boolean Status = strStatus.equals("strString");
		System.out.println("The boolean representation of strStatus is: " + Status);
		
	
	}
}
OUTPUT:-The boolean representation of strStatus is: false
*/

/*e. Declare a method-local variable status of type boolean with the value true and convert it to the corresponding wrapper class
 *  using Boolean.valueOf(). (Hint: Use Boolean.valueOf(boolean)).

public class Example2 {
	public static void main(String[] args) { 
		String strStatus = "1";
		Boolean Status = Boolean.valueOf(false);
		System.out.println(Status);
		
	}
}
OUTPUT:-false
*/

/*f. Declare a method-local variable strStatus of type String with the value "true" and convert it to the corresponding wrapper class using
Boolean.valueOf(). (Hint: Use Boolean.valueOf(String)).

public class Example2 {
	public static void main(String[] args) { 
		String strStatus = "true";
		   Boolean booleanWrapper = Boolean.valueOf(strStatus);
		System.out.println("boolean is : " + booleanWrapper);
	}
}
OUTPUT:-boolean is : true
*/

/*g. Experiment with converting a boolean value into other primitive types or vice versa and observe the results.

public class Example2 {
	public static void main(String[] args) { 
		boolean status = true;
        int intValue = (status) ? 1 : 0;
        System.out.println("Boolean to int: " + intValue);
	}
}
OUTPUT:-Boolean to int: 1
*/



