//package Q9;
//
//public class Example9{
//	 static int i;
//	   static float f; 
//	  static double d;
//	  static boolean b;
//	  static long l;
//	  static byte y;
//	 
//	 public static void main(String args[]) {
//	  System.out.println(" int :"+i+" float : "+f+" double : "+d+" boolean "
//	  +b+" long "+l+" byte: "+b);}}
//OUTPUT= int :0 float : 0.0 double : 0.0 boolean false long 0 byte: false
