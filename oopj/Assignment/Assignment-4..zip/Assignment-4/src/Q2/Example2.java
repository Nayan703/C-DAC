package Q2;


/*b. Write a program to test how many bytes are used to represent a byte value using the BYTES field. 
 * (Hint: Use Byte.BYTES).
 * 
public class Example2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println("The Number of bytes is  used to represent  byte: " + Byte.BYTES);
	}
}
*/

/*c. Write a program to find the minimum and maximum values of byte using the MIN_VALUE and MAX_VALUE fields. 
(Hint: Use Byte.MIN_VALUE and Byte.MAX_VALUE).


public class Example2 {
	public static void main(String[] args) {
		 System.out.println("Minimum value of byte: " + Byte.MIN_VALUE);

	        // Find and print the maximum value of a byte
	        System.out.println("Maximum value of byte: " + Byte.MAX_VALUE);
	}
}
output:Minimum value of byte: -128
Maximum value of byte: 127
*/

/*d. Declare a method-local variable number of type byte with some value and convert it to a String using the toString method. 
(Hint: Use Byte.toString(byte)).

public class Example2 {
	public static void main(String[] args) {
		 byte number = 20;
	        String numberString = Byte.toString(number);
	        System.out.println(" String representation the byte number is: " + numberString);
	}
}
OUTPUT:= String representation the byte number is: 20

e. Declare a method-local variable strNumber of type String with some value and convert it to a byte value using the parseByte method. 
(Hint: Use Byte.parseByte(String)).

public class Example2 {
	public static void main(String[] args) {
		String strNumber = "123";
        byte number = Byte.parseByte(strNumber);
        System.out.println("The byte value of the String is: " + number);
	}
}
OUTPUT:-The byte value of the String is: 123
*/

/*f. Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a byte value. 
(Hint: parseByte method will throw a NumberFormatException).

public class Example2 {
	public static void main(String[] args) {
		String strNumber = "Ab12Cd3";
		try {
			Byte number = Byte.parseByte(strNumber);
			System.out.println("The Byte value of String: " + number);
		} catch (NumberFormatException a) {
			System.out.println("Error : The string is not a valid byte value. ");
		}
	}
}
OUTPUT;=Error : The string is not a valid byte value. 
 * */

/*g. Declare a method-local variable number of type byte with some value and convert it to the corresponding wrapper class using
 *  Byte.valueOf().  (Hint: Use Byte.valueOf(byte)).

public class Example2 {
	public static void main(String[] args) {
		 byte number = 42;
	        Byte byteWrapper = Byte.valueOf(number);
	        System.out.println("The Byte wrapper representation of the byte number is: " + byteWrapper);
	}		
}
*/
/*h. Declare a method-local variable strNumber of type String with some byte value and convert it to the corresponding wrapper class 
 * using Byte.valueOf(). (Hint: Use Byte.valueOf(String)).

public class Example2 {
	public static void main(String[] args) {
		String strNumber = "123";
		try {
			Byte byteWrapper = Byte.valueOf(strNumber);
			System.out.println("The Byte wrapper representation of the String is: " + byteWrapper);		
		} catch (NumberFormatException e) {
			System.out.println("Error: The string is not a valid byte value.");
		}	
	}
}
OUTPUT:-The Byte wrapper representation of the String is: 123
*/

/*i. Experiment with converting a byte value into other primitive types or vice versa and observe the results.
 * 
	
public class Example2 {
	public static void main(String[] args) {
		   double doubleValue = 123.45;
	        byte byteValue = (byte) doubleValue;
	        System.out.println("Double to byte: " + byteValue);
	}		
}
OUTPUT:-Double to byte: 123
*/


















