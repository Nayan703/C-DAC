package Q4;

/*b. Write a program to test how many bytes are used to represent an int value using the BYTES field. (Hint: Use Integer.BYTES).
public class Example4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println("The Number of bytes is  used to represent  byte: " + Integer.BYTES);
			}
	}
OUTPUT=The Number of bytes is  used to represent  byte: 4
*/

/*c. Write a program to find the minimum and maximum values of int using the MIN_VALUE and MAX_VALUE fields.
(Hint: Use Integer.MIN_VALUE and Integer.MAX_VALUE).

public class Example4 {
	public static void main(String[] args) {
		 System.out.println("Minimum value of int: " + Integer.MIN_VALUE);

	        // Find and print the maximum value of a byte
	        System.out.println("Maximum value of int: " + Integer.MAX_VALUE);
	}
}
OUTPUT=Minimum value of int: -2147483648
Maximum value of int: 2147483647
*/

/*d. Declare a method-local variable number of type int with some value and convert it to a String using the toString method.
(Hint: Use Integer.toString(int)).

public class Example4 {
	public static void main(String[] args) {
		 int number = 20;
	        String numberString = Integer.toString(number);
	        System.out.println(" String representation the byte number is: " + numberString);
	}
}
OUTPUT= String representation the byte number is: 20
*/

/*e. Declare a method-local variable strNumber of type String with some value and convert it to an int value using the parseInt method. 
(Hint: Use Integer.parseInt(String)).

public class Example4 {
	public static void main(String[] args) {
		String strNumber = "123";
        int number = Integer.parseInt(strNumber);
        System.out.println("The int value of the String is: " + number);
	}
}
OUTPUT=The int value of the String is: 123
*/

/*f. Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to an int value. 
(Hint: parseInt method will throw a NumberFormatException).
 
public class Example4 {
	public static void main(String[] args) {
		String strNumber = "Ab12Cd3";
		try {
			int number = Integer.parseInt(strNumber);
			System.out.println("The Int value of String: " + number);
		} catch (NumberFormatException a) {
			System.out.println("Error : The string is not a valid Int value. ");
		}
	}
}
OUTPUT=Error : The string is not a valid Int value. 
*/

/*g. Declare a method-local variable number of type int with some value and convert it to the corresponding wrapper class using Integer.valueOf(). 
(Hint: Use Integer.valueOf(int)).

public class Example4 {
	public static void main(String[] args) {
		 int number = 42;
	        int IntWrapper = Integer.valueOf(number);
	        System.out.println("The int wrapper representation of the int  number is: " + IntWrapper);
	}		
}
OUTPUT=The int wrapper representation of the int  number is: 42
*/

/*h. Declare a method-local variable strNumber of type String with some integer value and convert it to the
 *  corresponding wrapper class using Integer.valueOf(). (Hint: Use Integer.valueOf(String)).

public class Example4 {
	public static void main(String[] args) {
		String strNumber = "123";
		try {
			int intWrapper = Integer.valueOf(strNumber);
			System.out.println("The Integer wrapper representation of the String is: " + intWrapper);		
		} catch (NumberFormatException i) {
			System.out.println("Error: The string is not a valid int value.");
		}	
	}
}
OUTPUT=The Integer wrapper representation of the String is: 123
*/

/*i. Declare two integer variables with values 10 and 20, and add them using a method from the Integer class. 
(Hint: Use Integer.sum(int, int)).

public class Example4 {
	public static void main(String[] args) {
		   int num1 = 10;
		   int num2 =20;
		   
	        int sum = Integer.sum(num1 , num2);
	        System.out.println("The sum  is: " + sum);
	}		
}
OUTPUT=The sum  is: 30
*/
/*j. Declare two integer variables with values 10 and 20, and find the minimum and maximum values using the Integer class. 
(Hint: Use Integer.min(int, int) and Integer.max(int, int)).

public class Example4{
	public static void main (String[] args) {
		int num1 =10;
		int  num2 = 20;
		int min =   Integer.min(num1 , num2);
		int max =   Integer.max(num1 , num2);
		 
		 System.out.println ("The sum is: " + min );
		 System.out.println ("The sum is: " + max );		
	}
}
OUTPUT=The sum is: 10
The sum is: 20
*/


/*k. Declare an integer variable with the value 7. Convert it to binary, octal, and hexadecimal strings using 
methods from the Integer class. (Hint: Use Integer.toBinaryString(int), Integer.toOctalString(int), and Integer.toHexString(int)).

public class Example4{
	public static void main (String[] args) {
		int num = 7;
		
		String binaryString = Integer.toBinaryString(num);
		String octalString  = Integer.toOctalString(num);
		String hexString   = Integer.toHexString(num);
		
		System.out.println ("Binary reperasentation of 7: " + binaryString);
		System.out.println("Octal representation of 7: " + octalString);
        System.out.println("Hexadecimal representation of 7: " + hexString);
        
	}
		
}
OUTPUT=Binary reperasentation of 7: 111
Octal representation of 7: 7
Hexadecimal representation of 7: 7
*/

/*l. Experiment with converting an int value into other primitive types or vice versa and observe the results.

public class Example4{
	public static void main (String[] args) {  
		int intValue =100;
		
		  byte byteValue = (byte) intValue;       
	        short shortValue = (short) intValue;     
	        long longValue = intValue;               
	        float floatValue = intValue;             
	        double doubleValue = intValue;        

        System.out.println("Integer to byte: " + byteValue);
        System.out.println("Integer to short: " + shortValue);
        System.out.println("Integer to long: " + longValue);
        System.out.println("Integer to float: " + floatValue);
        System.out.println("Integer to double: " + doubleValue);

        double anotherDouble = 111.456;
        int fromDouble = (int) anotherDouble;  

        long anotherLong = 5000L;
        int fromLong = (int) anotherLong;       

        float anotherFloat = 89.45f;
        int fromFloat = (int) anotherFloat;  

        System.out.println("Double to int: " + fromDouble);
        System.out.println("Long to int: " + fromLong);
        System.out.println("Float to int: " + fromFloat);	
	}
}
OUTPUT=Integer to byte: 100
Integer to short: 100
Integer to long: 100
Integer to float: 100.0
Integer to double: 100.0
Double to int: 111
Long to int: 5000
Float to int: 89
*/











