package Q3;

/*b. Write a program to test how many bytes are used to represent a short value using the BYTES field. (Hint: Use Short.BYTES).
public class Example3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println("The Number of bytes is  used to represent  byte: " + Short.BYTES);

	}

}
OUTPUT:-The Number of bytes is  used to represent  byte: 2
*/

/*c. Write a program to find the minimum and maximum values of short using the MIN_VALUE and MAX_VALUE fields.
(Hint: Use Short.MIN_VALUE and Short.MAX_VALUE).


public class Example3 {
	public static void main(String[] args) {
		 System.out.println("Minimum value of byte: " + Short.MIN_VALUE);

	        // Find and print the maximum value of a byte
	        System.out.println("Maximum value of byte: " + Short.MAX_VALUE);
	}
}
OUTPUT:=Minimum value of byte: -32768
Maximum value of byte: 32767
*/

/*d. Declare a method-local variable number of type short with some value and convert it to a String using the toString method. 
(Hint: Use Short.toString(short)).

public class Example3 {
	public static void main(String[] args) {
		 Short number = 20;
	        String numberString = Short.toString(number);
	        System.out.println(" String representation the Short number is: " + numberString);
	}
}
OUTPUT= String representation the Short number is: 20
*/

/*e. Declare a method-local variable strNumber of type String with some value and convert it to a short value using the parseShort method.
(Hint: Use Short.parseShort(String)).

public class Example3 {
	public static void main(String[] args) {
		String strNumber = "123";
        Short number = Short.parseShort(strNumber);
        System.out.println("The short value of the String is: " + number);
	}
}
OUTPUT=The short value of the String is: 123
*/

/*f. Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a short value. 
(Hint: parseShort method will throw a NumberFormatException).

public class Example3{
	public static void main(String[] args) {
		String strNumber = "Ab12Cd3";
		try {
			Short number = Short.parseShort(strNumber);
			System.out.println("The Short value of String: " + number);
		} catch (NumberFormatException a) {
			System.out.println("Error : The string is not a valid byte value. ");
		}
	}
}
OUTPUT=Error : The string is not a valid byte value. 
*/

/*g. Declare a method-local variable number of type short with some value and convert it to the corresponding wrapper class using Short.valueOf().
(Hint: Use Short.valueOf(short)).

public class Example3 {
	public static void main(String[] args) {
		 Short number = 42;
	        Short  shortWrapper = Short.valueOf(number);
	        System.out.println("The Short wrapper representation of the byte number is: " + shortWrapper);
	}		
}
OUTPUT=The Short wrapper representation of the byte number is: 42
*/

/*h. Declare a method-local variable strNumber of type String with some short value and convert it to the corresponding wrapper class using Short.valueOf().
(Hint: Use Short.valueOf(String)).

public class Example3 {
	public static void main(String[] args) {
		String strNumber = "123";
		try {
			Short shortWrapper = Short.valueOf(strNumber);
			System.out.println("The Short wrapper representation of the String is: " + shortWrapper);		
		} catch (NumberFormatException e) {
			System.out.println("Error: The string is not a valid short value.");
		}	
	}
}
OUTPUT=The Short wrapper representation of the String is: 123
*/

/*i. Experiment with converting a short value into other primitive types or vice versa and observe the results.
public class Example3 {
	public static void main(String[] args) {
		   double doubleValue = 123.45;
	        Short shortValue = (short) doubleValue;
	        System.out.println("Double to short: " + shortValue);
	}		
}
OUTPUT=Double to short: 123
*/















