package Q5;

/*b. Write a program to test how many bytes are used to represent a long value using the BYTES field. 
(Hint: Use Long.BYTES).
public class Example5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("The Number of bytes is  used to represent  long: " + Long.BYTES);
	}
}
OUTPUT=The Number of bytes is  used to represent  long: 8*/

/*c. Write a program to find the minimum and maximum values of long using the MIN_VALUE and MAX_VALUE fields. 
(Hint: Use Long.MIN_VALUE and Long.MAX_VALUE).

public class Example5 {

	public static void main(String[] args) {
		long minValue= Long.MIN_VALUE;
		long maxValue = Long.MAX_VALUE;
		
		System.out.println("minimum value of long  " + minValue);
		System.out.println("minimum value of long  " + maxValue);		
	}
}
OUTPUT= minimum value of long  -9223372036854775808
minimum value of long  9223372036854775807
*/

/*d. Declare a method-local variable number of type long with some value and convert it to a String using the toString method. 
(Hint: Use Long.toString(long)).

public class Example5 {
    public static void main(String[] args) {
        long number = 123456789L;  
        String strNumber = Long.toString(number);  
        System.out.println("String representation of long: " + strNumber);
    }
}
OUTPUT=String representation of long: 123456789
*/

/*e. Declare a method-local variable strNumber of type String with some value and convert it to a long value using the parseLong method. 
(Hint: Use Long.parseLong(String)).

public class Example5 {

    public static void main(String[] args) {
        String strNumber = "123456789";  
        long number = Long.parseLong(strNumber);  
        System.out.println("Long value from String: " + number);
    }
}


/*f. Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a long value. 
(Hint: parseLong method will throw a NumberFormatException).

public class Example5 {
    public static void main(String[] args) {
        String strNumber = "Ab12Cd3";  
        try {
            long number = Long.parseLong(strNumber);  
            System.out.println("Converted long value: " + number);
        } catch (NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
OUTPUT=Error: For input string: "Ab12Cd3"
*/

/*g. Declare a method-local variable number of type long with some value and convert it to the corresponding wrapper class using Long.valueOf().
(Hint: Use Long.valueOf(long)).

public class Example5 {

    public static void main(String[] args) {
        long number = 987654321L;  
        Long wrappedNumber = Long.valueOf(number);  
        System.out.println("Wrapped long value: " + wrappedNumber);
    }
}
OUTPUT=Wrapped long value: 987654321
*/

/*h. Declare a method-local variable strNumber of type String with some long value and convert it to the corresponding wrapper class using Long.valueOf().
(Hint: Use Long.valueOf(String)).

public class Example5 {
    public static void main(String[] args) {
        String strNumber = "987654321";  
        Long wrappedNumber = Long.valueOf(strNumber);  
        System.out.println("Wrapped String to Long: " + wrappedNumber);
    }
}
OUTPUT=Wrapped String to Long: 987654321
*/

/*i. Declare two long variables with values 1123 and 9845, and add them using a method from the Long class. (Hint: Use Long.sum(long, long)).

public class Example5 {
    public static void main(String[] args) {
        long num1 = 1123L;
        long num2 = 9845L;
        long sum = Long.sum(num1, num2);  
        System.out.println("Sum of " + num1 + " and " + num2 + " is: " + sum);
    }
}
OUTPUT=Sum of 1123 and 9845 is: 10968
*/

/*j. Declare two long variables with values 1122 and 5566, and find the minimum and maximum values using the Long class. 
(Hint: Use Long.min(long, long) and Long.max(long, long)).

public class Example5 {
    public static void main(String[] args) {
        long num1 = 1122L;
        long num2 = 5566L;

        long min = Long.min(num1, num2);  
        long max = Long.max(num1, num2);  

        System.out.println("Minimum value: " + min);
        System.out.println("Maximum value: " + max);
    }
}
OUTPUT=Minimum value: 1122
Maximum value: 5566
*/

/*k. Declare a long variable with the value 7. Convert it to binary, octal, and hexadecimal strings using methods 
from the Long class. (Hint: Use Long.toBinaryString(long), Long.toOctalString(long), and Long.toHexString(long)).

public class Example5 {
    public static void main(String[] args) {
        long number = 7L;

        String binaryString = Long.toBinaryString(number);
        String octalString = Long.toOctalString(number);
        String hexString = Long.toHexString(number);

        System.out.println("Binary representation of 7: " + binaryString);
        System.out.println("Octal representation of 7: " + octalString);
        System.out.println("Hexadecimal representation of 7: " + hexString);
    }
}OUTPUT=Binary representation of 7: 111
Octal representation of 7: 7
Hexadecimal representation of 7: 7
*/

/*l. Experiment with converting a long value into other primitive types or vice versa and observe the results.

public class Example5 {

    public static void main(String[] args) {
        long longValue = 5000L;

        int intValue = (int) longValue; 
        short shortValue = (short) longValue;
        byte byteValue = (byte) longValue;  
        float floatValue = longValue;   
        double doubleValue = longValue; 

        System.out.println("Long to int: " + intValue);
        System.out.println("Long to short: " + shortValue);
        System.out.println("Long to byte: " + byteValue);
        System.out.println("Long to float: " + floatValue);
        System.out.println("Long to double: " + doubleValue);
    }
}
OUTPUT=Long to int: 5000
Long to short: 5000
Long to byte: -120
Long to float: 5000.0
Long to double: 5000.0
*/










