package Q6;

/*b. Write a program to test how many bytes are used to represent a float value using the BYTES field.
(Hint: Use Float.BYTES).

public class Example6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("The Number of bytes is  used to represent  long: " + Float.BYTES);		
	}

}
OUTPUT=The Number of bytes is  used to represent  long: 4
*/

/*c. Write a program to find the minimum and maximum values of float using the MIN_VALUE and MAX_VALUE fields. 
(Hint: Use Float.MIN_VALUE and Float.MAX_VALUE).

public class Example6 {

	public static void main(String[] args) {
		  float number = 45.67f;  
	        String numberStr = Float.toString(number);  
	        System.out.println("Float to String: " + numberStr);
	}
}
OUTPUT=Float to String: 45.67
*/

/*e. Declare a method-local variable strNumber of type String with some value and convert it to a float value using the parseFloat method.
(Hint: Use Float.parseFloat(String)).
public class Example6 {
    public static void main(String[] args) {
        String strNumber = "123.45";  
        float parsedFloat = Float.parseFloat(strNumber);  
        System.out.println("String to float: " + parsedFloat);  
    }
}
OUTPUT=String to float: 123.45
*/

/*f. Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to 
convert it to a float value. (Hint: parseFloat method will throw a NumberFormatException).

public class Example6 {
    public static void main(String[] args) {
        String strNumber = "Ab12Cd3"; 
        try {
            float invalidFloat = Float.parseFloat(strNumber); 
            System.out.println("Float value: " + invalidFloat);  
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException: " + e.getMessage()); 
        }
    }
}
OUTPUT=NumberFormatException: For input string: "Ab12Cd3"
*/
//g. Declare a method-local variable number of type float with some value and convert it to the corresponding wrapper class using
//float.valueOf(). (Hint: Use Float.valueOf(float)).

//public class Example6 {
//    public static void main(String[] args) {
//        float number = 45.67f;  
//        Float floatWrapper = Float.valueOf(number);  
//        System.out.println("Wrapper class Float: " + floatWrapper);  
//    }
//}
//OUTPUT=Wrapper class Float: 45.67

//h. Declare a method-local variable strNumber of type String with some float value and convert it to the corresponding wrapper class using
//Float.valueOf(). (Hint: Use Float.valueOf(String)).

//public class Example6 {
//    public static void main(String[] args) {
//        String strNumber = "123.45";  
//        Float wrapperFromStr = Float.valueOf(strNumber);  
//        System.out.println("String to Float wrapper: " + wrapperFromStr);  
//    }
//}
//OUTPUT=String to Float wrapper: 123.45

//i. Declare two float variables with values 112.3 and 984.5, and add them using a method from the Float class. 
//(Hint: Use Float.sum(float, float)).

//public class Example6 {
//    public static void main(String[] args) {
//        float num1 = 112.3f; 
//        float num2 = 984.5f;  
//        float sum = Float.sum(num1, num2);  
//        System.out.println("Sum of " + num1 + " and " + num2 + ": " + sum);  
//    }
//}
//OUTPUT=Sum of 112.3 and 984.5: 1096.8

//j. Declare two float variables with values 112.2 and 556.6, and find the minimum and maximum values using the
//Float class. (Hint: Use Float.min(float, float) and Float.max(float, float)).

//public class Example6 {
//    public static void main(String[] args) {
//        float num1 = 112.2f;  
//        float num2 = 556.6f;  
//        float minValue = Float.min(num1, num2);  
//        float maxValue = Float.max(num1, num2);  
//        System.out.println("Minimum value: " + minValue); 
//        System.out.println("Maximum value: " + maxValue); 
//    }
//}
//OUTPUT+Minimum value: 112.2
//Maximum value: 556.6

//k. Declare a float variable with the value -25.0f. Find the square root of this value. (Hint: Use Math.sqrt() method).

//public class Example6 {
//    public static void main(String[] args) {
//        float number = -25.0f;  
//        double sqrtResult = Math.sqrt(number); 
//        System.out.println("Square root of " + number + ": " + sqrtResult); 
//    }
//}
//OUTPUT=Square root of -25.0: NaN

//l. Declare two float variables with the same value, 0.0f, and divide them. (Hint: Observe the result and any special floating-point behavior).

//public class Example6 {
//    public static void main(String[] args) {
//        float zero1 = 0.0f;  
//        float zero2 = 0.0f;  
//        float result = zero1 / zero2;  
//        System.out.println("Result of 0.0f / 0.0f: " + result);  
//    }
//}
//OUTPUT=Result of 0.0f / 0.0f: NaN

//m. Experiment with converting a float value into other primitive types or vice versa and observe the results.

//public class Example6 {
//    public static void main(String[] args) {
//        float floatValue = 123.45f;  
//
//        int intValue = (int) floatValue;  
//        long longValue = (long) floatValue;  
//        double doubleValue = (double) floatValue;  
//
//        System.out.println("Float to int: " + intValue);  
//        System.out.println("Float to long: " + longValue);  
//        System.out.println("Float to double: " + doubleValue);  
//    }
//}
//OUTPUT=Float to int: 123
//Float to long: 123
//Float to double: 123.44999694824219































