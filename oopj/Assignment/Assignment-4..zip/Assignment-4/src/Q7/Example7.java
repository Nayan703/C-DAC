package Q7;

//b. Write a program to test how many bytes are used to represent a double value using the BYTES field.
//(Hint: Use Double.BYTES).
//public class Example7 {
//    public static void main(String[] args) {
//        int doubleBytes = Double.BYTES;  
//        System.out.println("Bytes used to represent a double: " + doubleBytes);
//    }
//}
//OUTPUT=Bytes used to represent a double: 8

//c. Write a program to find the minimum and maximum values of double using the MIN_VALUE and MAX_VALUE fields. (Hint: Use Double.MIN_VALUE and Double.MAX_VALUE).
//public class Example7 {
//    public static void main(String[] args) {
//        double minDouble = Double.MIN_VALUE; 
//        double maxDouble = Double.MAX_VALUE;  
//        System.out.println("Minimum double value: " + minDouble);
//        System.out.println("Maximum double value: " + maxDouble);
//    }
//}
//OUTPUT=Minimum double value: 4.9E-324
//Maximum double value: 1.7976931348623157E308

//d. Declare a method-local variable number of type double with some value and convert it to a String using the toString method. (Hint: Use Double.toString(double)).
//public class Example7 {
//    public static void main(String[] args) {
//        double number = 456.78;  
//        String numberStr = Double.toString(number);  
//        System.out.println("Double to String: " + numberStr);
//    }
//}
//OUTPUT=Double to String: 456.78

//e. Declare a method-local variable strNumber of type String with some value and convert it to a double value using the parseDouble method. (Hint: Use Double.parseDouble(String)).

//public class Example7 {
//    public static void main(String[] args) {
//        String strNumber = "789.12";  
//        double parsedDouble = Double.parseDouble(strNumber);  
//        System.out.println("String to double: " + parsedDouble);
//    }
//}
//OUTPUT=String to double: 789.12

//f. Declare a method-local variable strNumber of type String with the value "Ab12Cd3" and attempt to convert it to a double value. (Hint: parseDouble method will throw a NumberFormatException).

//public class Example7 {
//    public static void main(String[] args) {
//        String strNumber = "Ab12Cd3";  
//        try {
//            double invalidDouble = Double.parseDouble(strNumber);  
//            System.out.println("Double value: " + invalidDouble); 
//        } catch (NumberFormatException e) 
//            System.out.println("NumberFormatException: " + e.getMessage());  
//        }
//    }
//}
//OUTPUT=NumberFormatException: For input string: "Ab12Cd3"

//g. Declare a method-local variable number of type double with some value and convert it to the corresponding wrapper class using Double.valueOf(). (Hint: Use Double.valueOf(double)).

//public class Example7 {
//    public static void main(String[] args) {
//        double number = 123.45;  
//        Double doubleWrapper = Double.valueOf(number);  
//        System.out.println("Wrapper class Double: " + doubleWrapper);
//    }
//}
//OUTPUT=Wrapper class Double: 123.45

//h. Declare a method-local variable strNumber of type String with some double value and convert it to the corresponding wrapper class using Double.valueOf(). (Hint: Use Double.valueOf(String)).

//public class Example7 {
//public static void main(String[] args) {
//    String strNumber = "123.45"; 
//    Double wrapperFromStr = Double.valueOf(strNumber); 
//    System.out.println("String to Double wrapper: " + wrapperFromStr);
//}
//}
//OUTPUT=String to Double wrapper: 123.45

//i. Declare two double variables with values 112.3 and 984.5, and add them using a method from the Double class. (Hint: Use Double.sum(double, double)).

//public class Example7 {
//    public static void main(String[] args) {
//        double num1 = 112.3;  
//        double num2 = 984.5; 
//        double sum = Double.sum(num1, num2);  
//        System.out.println("Sum of " + num1 + " and " + num2 + ": " + sum);
//    }
//}
//OUTPUT=Sum of 112.3 and 984.5: 1096.8

//j. Declare two double variables with values 112.2 and 556.6, and find the minimum and maximum values using the Double class. (Hint: Use Double.min(double, double) and Double.max(double, double)).

//public class Example7 {
//    public static void main(String[] args) {
//        double num1 = 112.2; 
//        double num2 = 556.6;  
//        double minValue = Double.min(num1, num2);  
//        double maxValue = Double.max(num1, num2);  
//        System.out.println("Minimum value: " + minValue);
//        System.out.println("Maximum value: " + maxValue);
//    }
//}
//OUTPUT=Minimum value: 112.2
//Maximum value: 556.6

//k. Declare a double variable with the value -25.0. Find the square root of this value. (Hint: Use Math.sqrt() method).

//public class Example7 {
//    public static void main(String[] args) {
//        double number = -25.0;  
//        double sqrtResult = Math.sqrt(number); 
//        System.out.println("Square root of " + number + ": " + sqrtResult);  
//}
//OUTPUT=Square root of -25.0: NaN

//l. Declare two double variables with the same value, 0.0, and divide them. (Hint: Observe the result and any special floating-point behavior).

//public class Example7 {
//    public static void main(String[] args) {
//        double zero1 = 0.0;  
//        double zero2 = 0.0; 
//        double result = zero1 / zero2;  
//        System.out.println("Result of 0.0 / 0.0: " + result);  
//    }
//}
//OUTPUT=Result of 0.0 / 0.0: NaN

//m. Experiment with converting a double value into other primitive types or vice versa and observe the results.

//public class Example7 {
//    public static void main(String[] args) {
//        double doubleValue = 456.78;  
//
//        int intValue = (int) doubleValue;  
//        long longValue = (long) doubleValue; 
//        float floatValue = (float) doubleValue;  
//
//        System.out.println("Double to int: " + intValue);  
//        System.out.println("Double to long: " + longValue); 
//        System.out.println("Double to float: " + floatValue);  
//}
//OUTPUT= Double to int: 456
//Double to long: 456
//Double to float: 456.78





























