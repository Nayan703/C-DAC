package ADSA;

import java.util.*;
public class RemoveRepeatedQ7 {

    public static Set<Character> findRepeatedCharacters(String str) {
        Set<Character> seen = new HashSet<>();
        Set<Character> repeated = new HashSet<>();

 
        for (char c : str.toCharArray()) {
        
            if (seen.contains(c)) {
                repeated.add(c);
            } else {
           
                seen.add(c);
            }
        }

        return repeated;
    }

    public static void main(String[] args) {
      
    	  try (Scanner sc = new Scanner (System.in)) {
			System.out.println("Enter the string :");
			  String str = sc.nextLine();

			System.out.println("Repeated characters in \"" + str + "\": " + findRepeatedCharacters(str));
		}
    }
}
//output
//Enter the string :
//5  6  7 8  7  2  5 7  9   0   2   1   4 7  8
//Repeated characters in "5  6  7 8  7  2  5 7  9   0   2   1   4 7  8": [ , 2, 5, 7, 8]
//O(n)