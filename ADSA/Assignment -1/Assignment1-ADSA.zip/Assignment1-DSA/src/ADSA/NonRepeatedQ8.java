package ADSA;

import java.util.*;
public class NonRepeatedQ8 {
	public static Character findFirstNonRepeatedCharacter(String str) {
   
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
         
            if (str.indexOf(c) == str.lastIndexOf(c)) {
                return c;
            }
        }
        return null; 
    }

    public static void main(String[] args) {
        // Test cases
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter the string :");
        String str = sc.nextLine();
        
        System.out.println("First non-repeated character in \"" + str + "\": " + findFirstNonRepeatedCharacter(str));
        sc.close();
    }
}

//output
//Enter the string :
//3  4  6   7 8 9 4 56  6 7 3 
//First non-repeated character in "3  4  6   7 8 9 4 56  6 7 3 ": 8
//

//O(n^2)
