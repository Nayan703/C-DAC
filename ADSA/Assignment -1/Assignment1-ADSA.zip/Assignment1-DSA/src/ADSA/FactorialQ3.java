package ADSA;

import java.util.Scanner;
public class FactorialQ3 {
	 public static int factorial(int num) {
	        int res = 1;
	        for (int i = 1; i <= num; i++) {
	            res *= i;
	        }
	        return res;
	    }
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int num = sc.nextInt();
		sc.close();
		System.out.println(factorial(num));
	}

}            
//output
//Enter the number: 
//33
//-2147483648

//T = O (n)                                           
//S = O(1

