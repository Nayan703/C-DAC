package ADSA;

import java.util.Scanner;
public class SquareRootQ6 {
	public static int findSquareRoot(int x) {
        int result = 0;
        
        for (int i = 1; i * i <= x; i++) {
            result = i;
        }
        
        return result;
    }
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int x = sc.nextInt();
		System.out.println("The square root of " + x + " is: " + findSquareRoot(x));
        sc.close();
		
	}
}
//output
//Enter the number: 
//25
//The square root of 25 is: 5
