package ADSA;

import java.util.Scanner;
public class FibonacciSeriesQ4 {
	public static void printRecord(int num) {
        int first = 0, second = 1;
        
        if (num > 0) {
            System.out.print("[" + first);
        }
        if (num > 1) {
            System.out.print(", " + second); 
        }
        
        for (int i = 3; i <= num; i++) {
            int next = first + second;
            System.out.print(", " + next);
            first = second;
            second = next;
        }

        System.out.println("]");
    }

	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number upto which you want seris: ");
		int num = sc.nextInt();
		printRecord(num);
		sc.close();
	}

}
//Output
//Enter number upto which you want seris: 
//12
//[0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
//T = O (n)                                                                                                                                                                                    
//S = O(1)
