package ADSA;

import java.util.Scanner;

public class LeapYearCheckeQ10 {

    public static boolean isLeapYear(int year) {
     
        if (year % 400 == 0) {
            return true; 
        } else if (year % 100 == 0) {
            return false; 
        } else if (year % 4 == 0) {
            return true; 
        } else {
            return false; 
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a year: ");
        int year = sc.nextInt();
        
        boolean result = isLeapYear(year);
        System.out.println("Is " + year + " a leap year? " + result);
        
        sc.close();
    }
}
//output
//Enter a year: 2012
//Is 2012 a leap year? true

//Enter a year: 2013
//Is 2013 a leap year? false


//O(1)
		