package ADSA;

import java.util.Scanner;

public class ArmstrongNumberQ1 {
    
    public static boolean isArmstrong(int number) {
        int temp = number, digits = 0, sum = 0;
        
        // Find the number of digits
        while (temp > 0) {
            digits++;
            temp /= 10;
        }
        
        temp = number;  // Reset temp to original number
        
        // Calculate the sum of digits raised to the power of digits
        while (temp > 0) {
            int digit = temp % 10;
            sum += Math.pow(digit, digits);  // Math.pow(base, exponent)
            temp /= 10;
        }
        
        // Check if the sum equals the original number
        return sum == number;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = sc.nextInt();
        
        if (isArmstrong(number)) {
            System.out.println(number + " is an Armstrong number.");
        } else {
            System.out.println(number + " is not an Armstrong number.");
        }
        
        sc.close();
    }
}

//output
//Enter a number: 22
//22 is not an Armstrong number.


