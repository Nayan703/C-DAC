package ADSA;

import java.util.Scanner;

public class IntegerPalindromQ9 {
    
    public static boolean isPalindrome(int num) {
       
        if (num < 0) {
            return false;
        }
        
        int originalNum = num; 
        int reversedNum = 0;   
        
      
        while (num != 0) {
            int lastDigit = num % 10; 
            reversedNum = reversedNum * 10 + lastDigit; 
            num /= 10; 
        }
        
    
        return originalNum == reversedNum;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int num = sc.nextInt();
        
        boolean result = isPalindrome(num);
      System.out.println(" Is the number a palindrome?   "    + result);
        
        sc.close();
    }
}
//output
//Enter an integer: 34
//Is the number a palindrome?   false
//O(log10(n)) 
